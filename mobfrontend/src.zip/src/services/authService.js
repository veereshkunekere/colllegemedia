import API from "./api";
import {ensureIdentityKeys} from "./cryptoService";
import {getSocket} from "../services/socket";
import { useChatStore } from "../store/chatStore";
export const syncPublicKeyToServer = async (token, publicKey) => {
  if (!token || !publicKey) return null;

  try {
    await API.post(
      "/user/updatePublicKey",
      { publicKey },
      {
        headers: {
          Authorization: "Bearer " + token
        }
      }
    );
    console.log("public Key changed");
  } catch (error) {
    console.warn("Failed to sync public key to server", error);
  }
};

export const loginUser = async ( email, password ) => {
    try {
      const response =
        await API.post(
          "/auth/login",
          {
            email,
            password,
          }
        );

      const keys = await ensureIdentityKeys();
      const shouldSyncKey = !response.data?.user?.publicKey || response.data.user.publicKey !== keys.publicKey;

      if (shouldSyncKey) {
        await syncPublicKeyToServer(response.data.token, keys.publicKey);
        
        console.log("new keys",keys);
      }

      return response.data;
    } catch (error) {
      throw (
        error.response?.data ||
        error
      );
    }
  };

export const registerUser =  async (
    userData
  ) => {
    try {
      const {publicKey} = await ensureIdentityKeys();
      userData.publicKey = userData.publicKey || publicKey;
      const response =
        // await API.post(
        //   `/auth/register/${userData.token}`,
        //   userData
        // );
        await API.post("/auth/dsignup",userData); //TODO make signup route use instead of dsignup

      return response.data;
    } catch (error) {
      console.log("error in suthService registerUser",error);
      throw (
        error.response?.data ||
        error
      );
    }
  };

export const verifyToken =  async () => {
    try {
      const response =
        await API.get(
          "/auth/verify-token"
        );

      return response.data;
    } catch (error) {
      throw (
        error.response?.data ||
        error
      );
    }
  };

export const logoutUser =  async () => {
    try {
      const socket = getSocket();
      if (socket) socket.disconnect();
      useChatStore.setState({ socketConnected: false, currentUserId: null, activeConversation: null, messages: [], conversations: [] });
      const response =
        await API.post(
          "/auth/logout"
        );

      return response.data;
    } catch (error) {
      throw (
        error.response?.data ||
        error
      );
    }
  };

export const verifyEmail = async (email,password) =>{
    try {
      const response =
        await API.post(
          "/auth/verify-email",
          {
            email,
            password,
          }
        );

      return response.data;
    } catch (error) {
      throw (
        error.response?.data ||
        error
      );
    }
}

