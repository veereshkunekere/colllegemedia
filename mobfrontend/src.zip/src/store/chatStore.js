import { create }
  from "zustand";

import API
  from "../services/api";

import {
  connectSocket,
  getSocket,
} from "../services/socket";
import { useAuthStore } from "./authStore";
import * as SecureStore from "expo-secure-store";

import {loadSession,saveSession} from "../services/sessionServive";
import {ratchetChainKey, encryptMessage, decryptMessage, generateSkippedMessageKeys,getIdentityKeys,generateIdentityKeys,deriveSharedSecret,deriveInitialSessionKeys} from "../services/cryptoService"

export const useChatStore =
  create((set, get) => ({

    conversations: [],

    messages: [],

    activeConversation:
      null,

    socketConnected:
      false,
    
    onlineUsers: [],

    currentUserId:null,


    // CONNECT SOCKET

    connectRealtime:({token , userId}) => {
        
        if ( get().socketConnected) {
           return;
       }
         set({currentUserId:userId});
         const currentUserId = userId;
        const socket = connectSocket({token});
        socket.off("connect");
        socket.off("disconnect");
        socket.off("newMessage");
        socket.off("connect_error");

        socket.on("connect_error", (err) => {
             console.log("socket auth failed",err.message);
            }
        );

        socket.on( "connect",() => {
          console.log("socket connected",socket.id);
            set({
              socketConnected:
                true,
            });
          },
          
        );

        socket.on("disconnect",() => {
             set({ socketConnected: false,});
          });



        // NEW MESSAGE

        socket.on("newMessage", async (message) => {
          console.log("inside newMessage event",message);
          console.log("current uer",currentUserId)
          if(String(message.senderId) === String(currentUserId)){ return;}
          if ( message.conversationId !== get().activeConversation) return;
          const session = await loadSession( message.conversationId);
           if (!session) return;

    // FUTURE MESSAGE / SKIPPED KEYS

    if (  message.messageNumber > session.receiveMessageNumber + 1) {
      console.log("skipped msgs");

      const generated =

        await generateSkippedMessageKeys(

          session.receiveChainKey,

          session.receiveMessageNumber+1,

          message.messageNumber
        );

      session.skippedKeys = {

        ...session.skippedKeys,

        ...generated.skipped,
      };

      session.receiveChainKey =
        generated.finalChainKey;
    }

    // OLD MESSAGE

    else if ( message.messageNumber <= session.receiveMessageNumber ) {
      console.log("old skipped msg recieved")

      const skipped = session.skippedKeys[ message.messageNumber];

      if (!skipped) {
        return;
      }

      const decryptedText =

        await decryptMessage(

          message.cipherText,

          message.nonce,

          skipped.messageKey
        );

      delete session.skippedKeys[
        message.messageNumber
      ];

      await saveSession(
        message.conversationId,
        session
      );

      message.decryptedText =
        decryptedText;
      
      console.log(message);

      

      return;
    }

    // NORMAL MESSAGE
    console.log("before doing anything these are session in newMessage",session);
    console.log("recieved msg obj inside messageNumber",message);
    const {  messageKey, nextChainKey } = await ratchetChainKey(
        session.receiveChainKey
      );

    console.log("message KEY in newMessage", messageKey);
    console.log("recieve in newMessage",session.receiveChainKey);
    console.log("recieved nonce",message.nonce);
    let decryptedText
    try{
     decryptedText =

      await decryptMessage(

        message.cipherText,

        message.nonce,

        messageKey
      );}
        catch(e) {
          console.log("err in decrypting",e)
   console.log({
      receiveChainKey:
        session.receiveChainKey,
      receiveMessageNumber:
        session.receiveMessageNumber,
      incoming:
        message.messageNumber
   });

   return;
      }

      console.log("decryptMessage",decryptedText);
    session.receiveChainKey = nextChainKey;

    session.receiveMessageNumber =
      message.messageNumber;

    await saveSession(
      message.conversationId,
      session
    );

    message.decryptedText =
      decryptedText;

    // DELIVERY ACK

    if (
      message.senderId !==
      currentUserId
    ) {

      socket.emit(
        "messageDelivered",
        {
          messageId:
            message._id,
        }
      );
    }

    // DEDUPE

    set((state) => {

      const exists =

        state.messages.some(
          (msg) =>
            msg._id ===
            message._id
        );

      if (exists) {
        return state;
      }

      return {

        messages: [
          ...state.messages,
          message,
        ],
        
      };
    });
  }
);

        socket.on("messageDelivered", ({ messageId }) => {

               set((state) => ({

                messages:
                 state.messages.map(
                  (msg)=>

                   msg._id === messageId
                    ? {
                                   ...msg,
                        status:
                         "delivered",
                      }
                    : msg
                 ),
              }));
            }
           );

       socket.on( "messagesSeen", ({ conversationId }) => {


             set((state) => ({

                messages : state.messages.map( (msg) =>
                   msg.conversationId === conversationId &&
                    msg.senderId === currentUserId ? {
                                         ...msg,
                                         status: "seen",
                                    } : msg
                ),
             }));
  }
);
      },



    // LOAD INBOX

    loadMessages: async (conversationId) => {
  try {
    const res = await API.get(`/messages/${conversationId}`);
    const rawMessages = res.data.messages;
    const session = await loadSession(conversationId);

    if (!session) {
      set({ messages: rawMessages });
      return;
    }

    const decrypted = [];
    for (const msg of rawMessages) {
      if (msg.senderId === get().currentUserId) {
        // Own messages — already have decryptedText from optimistic UI or just show placeholder
        decrypted.push(msg);
        continue;
      }
      try {
        const { messageKey, nextChainKey } = await ratchetChainKey(session.receiveChainKey);
        const text = await decryptMessage(msg.cipherText, msg.nonce, messageKey);
        session.receiveChainKey = nextChainKey;
        session.receiveMessageNumber = msg.messageNumber;
        decrypted.push({ ...msg, decryptedText: text });
      } catch {
        decrypted.push({ ...msg, decryptedText: '[undecryptable]' });
      }
    }

    await saveSession(conversationId, session);
    set({ messages: decrypted });
  } catch (error) {
    console.log(error);
  }
},



    // OPEN CHAT

    openConversation:  async ( conversation,user) => {
      const conversationId=conversation._id;
      console.log("conversation",conversation,"conversationId",conversationId,"MyuserId",user);
        const existingSession = await loadSession(  conversationId );
        console.log("sessin",existingSession);
        if(!existingSession){
          let myKeys = await getIdentityKeys();
          console.log("my keys stroed are",myKeys);
          if (!myKeys?.privateKey || !myKeys?.publicKey) {
            console.log("Missing identity keys");
            return;
          }
          const receiver = conversation.participants.find(  (participant)=> 
          String(participant._id)!== String(user));
          const receiverId = receiver._id;
          console.log("MY ID",user);
          console.log("recieverId",receiverId);
          

          const res =  await API.get( `/user/publicKey/${receiverId}` );
          console.log("res for publicKey",res.data);
          const receiverPublicKey = res.data.publicKey;
          const sharedSecret = await deriveSharedSecret( myKeys.privateKey, receiverPublicKey );
          console.log("conversation createdBy",conversation.createdBy, "user:",user);
          const isInitiator = String(conversation.createdBy?._id || conversation.createdBy) ===String(user);
          const sessionKeys = await deriveInitialSessionKeys( sharedSecret, isInitiator);
          await saveSession(conversationId,{
                             ...sessionKeys,

                             sendMessageNumber:0,

                             receiveMessageNumber:-1,

                             skippedKeys:{},
                           }
                          );
        }
        set({
          activeConversation:
            conversationId,

          messages: [],
        });

        const socket = getSocket();

        socket.emit(
          "joinConversation",

          conversationId
        );

        await get()
          .loadMessages(
            conversationId
          );
      },



    // LOAD MESSAGES

    loadMessages:  async (
        conversationId
      ) => {

        try {

          const res =
            await API.get(
              `/messages/${conversationId}`
            );
          // console.log("result of loadMessages",res.data.messages);
          set({
            messages:
              res.data
                .messages,
          });

        } catch (
          error
        ) {
          console.log(
            error
          );
        }
      },



    // SEND MESSAGE

   sendMessage: async (payload) => {

  const session = await loadSession(
      payload.conversationId
    );

  if (!session) {

    console.log(
      "No session found"
    );

    return;
  }

  // CURRENT MESSAGE NUMBER

  const messageNumber = session.sendMessageNumber;
  
  console.log("message",payload,"no",messageNumber);

  // DERIVE MESSAGE KEY

  const {
    messageKey,
    nextChainKey,
  } =

    await ratchetChainKey(
      session.sendChainKey
    );

  // ENCRYPT

  const encrypted =

    await encryptMessage(

      payload.cipherText,

      messageKey
    );
    console.log("message Key",messageKey);
  console.log("sendChainKey",session.sendChainKey);
  console.log("nonce is",encrypted.nonce);
    console.log("encrypted msg",encrypted);
  // ADVANCE CHAIN

  session.sendChainKey =
    nextChainKey;

  session.sendMessageNumber =
    messageNumber + 1;

  await saveSession(

    payload.conversationId,

    session
  );
  
  console.log("after sending msg my session is",await loadSession(payload.conversationId));

  // OPTIMISTIC UI

  const optimisticMessage = {

    ...payload,

    _id:
      payload.clientTempId,

    decryptedText:
      payload.cipherText,

    cipherText:
      encrypted.cipherText,

    nonce:
      encrypted.nonce,

    messageNumber,

    previousChainLength:
      messageNumber,

    senderId:
      payload.senderId,

    status:
      "sending",

    optimistic:
      true,

    createdAt:
      new Date(),
  };

  // ADD IMMEDIATELY

  set((state) => ({

    messages: [
      ...state.messages,
      optimisticMessage,
    ],
  }));

  try {

    const securePayload = {

      conversationId:
        payload.conversationId,

      cipherText:
        encrypted.cipherText,

      nonce:
        encrypted.nonce,

      messageNumber,

      previousChainLength:
        messageNumber,
    };

    const res =

      await API.post(

        "/messages/sendMessage",

        securePayload,
      );

    const realMessage =
      res.data.newMessage;

    // REPLACE TEMP

    set((state) => {

      const withoutTemp =

        state.messages.filter(
          (msg) =>
            msg._id !==
            payload.clientTempId
        );

      const exists =

        withoutTemp.some(
          (msg) =>
            msg._id ===
            realMessage._id
        );

      return {

        messages:
          exists

            ? withoutTemp

            : [
                ...withoutTemp,

                {
                  ...realMessage,

                  decryptedText:
                    payload.cipherText,

                  status:
                    "sent",
                },
              ],
      };
    });

  } catch (error) {

    // MARK FAILED

    set((state) => ({

      messages:
        state.messages.map(
          (msg) =>

            msg._id ===
            payload.clientTempId

              ? {
                  ...msg,

                  status:
                    "failed",
                }

              : msg
        ),
    }));

    console.log(error);
  }
},

  }));