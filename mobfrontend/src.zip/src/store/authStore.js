import { create } from "zustand";

import {
  loginUser,
  logoutUser,
  registerUser,
  verifyToken,
  verifyEmail,
  signupUser
} from "../services/authService";

import {
  saveToken,
  getToken,
  removeToken,
} from "../utils/storage";

import { ensureIdentityKeys } from "../services/cryptoService";
import { syncPublicKeyToServer } from "../services/authService";
import {useChatStore} from "../store/chatStore"
export const useAuthStore =
  create((set,get) => ({
    user: null,

    token: null,

    loading: false,

    isCheckingAuth: true,

    login: async (
      email,
      password
    ) => {
      try {
        set({
          loading: true,
        });

        const data =
          await loginUser(
            email,
            password
          );

        await saveToken(
          data.token
        );

        console.log("token is",data.token);

        set({
          user: data.user,
          token: data.token,
        });
        const userId = get().user._id;

        useChatStore.getState().connectRealtime({token: data.token,userId});

        return {
          success: true,
        };
      }
       catch (error) {
        return {
          success: false,
          message:
            error.message ||
            "Login failed",
        };
      } 
      finally {
        set({
          loading: false,
        });
      }
    },

    logout: async () => {
      try {
        await logoutUser();

        await removeToken();

        set({
          user: null,
          token: null,
        });
      } catch (error) {
        console.log(
          "Logout Error:",
          error
        );
      }
    },

    verifyEmail: async (email,password)=>{
      try {
        set({loading:true});
        const data = await verifyEmail( email, password );
    
        return {
          success: true,
        };

      } catch (error) {
        return {
          success: false,
          message:
            error.message ||
            "Login failed",
        };
      }
      finally{
        set({
          loading: false,
        });
      }
    },

    checkAuth: async () => {
      try {
        const storedToken = await getToken();

        if (!storedToken) {
          console.log("token not found")
          set({
            isCheckingAuth:
              false,
          });

          return;
        }

        const data = await verifyToken();


        set({
          user: data.user,
          token:
            storedToken,
        });

        const keys = await ensureIdentityKeys();
        const shouldSyncKey = !data.user?.publicKey || data.user.publicKey !== keys.publicKey;

        if (shouldSyncKey) {
          await syncPublicKeyToServer(storedToken, keys.publicKey);
        }

        const userId = get().user._id;
        console.log(userId);

        useChatStore.getState().connectRealtime({token: storedToken,userId});
      } catch (error) {
        console.log(error);
        await removeToken();

        set({
          user: null,
          token: null,
        });
      } finally {
        set({
          isCheckingAuth:
            false,
        });
      }
    },

    signup: async (userData) =>{
        try {
        set({
          loading: true,
        });

        const data = await registerUser(userData);

        await saveToken( data.token);

        console.log("token is",data.token);

        set({
          user: data.user,
          token: data.token,
        });

        useChatStore.getState().connectRealtime({token: data.token,userId:data.user._id});

        return {
          success: true,
        };
      }
       catch (error) {
        console.log("error in authStore signup",error);
        return {
          success: false,
          message:
            error.message ||
            "Login failed",
        };
      } 
      finally {
        set({
          loading: false,
        });
      }
    }
  }));